# catagatchi
Cathacks 2016 submission


This is the Cathacks Hackathon submission from my team in 2016. This game was inspired by the Tamagotchi toys that each of us had played
with as children. The game was developed to play in a somewhat similar manner to the original game while featuring many faces and concepts
that could be found on the University of Kentucky's campus. The game plays as a live challenge to make the creature survive from egg stage
until the end with resource management being the primary challenge.

The game was developed in under 24 hours using C# and Microsoft Forms, a technology we had no prior experience with before this project.
Thank you for viewing our project, and enjoy the game!

Steven Gripshover,
Lead Designer
